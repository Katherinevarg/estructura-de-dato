#pragma once
#define MAX 100
#include "Nodo.h"

class Colad
{
private:
	Nodo info[MAX];
	int ini;
	int	fin;
public:
	Colad(void);
	bool Encolar(int Valor);
	bool Desencolar(void);
	bool PrimeroCola(int& Valor);
	bool ColaVacia(void);
	void mostrar(void);
};

